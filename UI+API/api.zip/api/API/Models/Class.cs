﻿namespace API.Models
{
    public class Class
    {
    }
}
