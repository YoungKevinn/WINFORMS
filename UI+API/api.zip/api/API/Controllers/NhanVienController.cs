﻿using API.DTOs;
using API.Models;
using API.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NhanVienController : ControllerBase
    {
        private readonly CafeDbContext _context;

        public NhanVienController(CafeDbContext context)
        {
            _context = context;
        }

        private static NhanVienViewDto ToViewDto(NhanVien nv) => new NhanVienViewDto
        {
            Id = nv.Id,
            MaNhanVien = nv.MaNhanVien,
            HoTen = nv.HoTen,
            VaiTro = nv.VaiTro,
            TenDangNhap = nv.TenDangNhap
        };

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<IEnumerable<NhanVienViewDto>>> GetAll()
        {
            var data = await _context.NhanViens
                .Select(nv => new NhanVienViewDto
                {
                    Id = nv.Id,
                    MaNhanVien = nv.MaNhanVien,
                    HoTen = nv.HoTen,
                    VaiTro = nv.VaiTro,
                    TenDangNhap = nv.TenDangNhap
                })
                .ToListAsync();

            return Ok(data);
        }

      
        [HttpGet("by-code/{maNhanVien}")]
        [Authorize]
        public async Task<ActionResult<NhanVienViewDto>> GetByMaNhanVien(string maNhanVien)
        {
            if (string.IsNullOrWhiteSpace(maNhanVien))
                return BadRequest("Mã nhân viên không hợp lệ");

            var nv = await _context.NhanViens
                .FirstOrDefaultAsync(x => x.MaNhanVien == maNhanVien);

            if (nv == null)
                return NotFound();

            return Ok(ToViewDto(nv));
        }

        [HttpGet("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<NhanVienViewDto>> GetById(int id)
        {
            var nv = await _context.NhanViens.FindAsync(id);
            if (nv == null) return NotFound();
            return Ok(ToViewDto(nv));
        }

    
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<NhanVienViewDto>> Create(
            NhanVienCreateUpdateDto dto,
            [FromHeader(Name = "X-NguoiThucHien")] string? nguoiThucHien)
        {
            if (string.IsNullOrWhiteSpace(dto.MaNhanVien))
                return BadRequest("Mã nhân viên là bắt buộc.");

            var ma = dto.MaNhanVien.Trim();

            var existed = await _context.NhanViens.AnyAsync(x => x.MaNhanVien == ma);
            if (existed)
                return BadRequest("Mã nhân viên đã tồn tại.");

            var nv = new NhanVien
            {
                MaNhanVien = ma,
                HoTen = dto.HoTen,
                VaiTro = string.IsNullOrWhiteSpace(dto.VaiTro) ? "NhanVien" : dto.VaiTro,
                TenDangNhap = ma, // 👈 login bằng MaNV
                MatKhauHash = PasswordHasher.CreatePasswordHash("123456")
            };

            _context.NhanViens.Add(nv);
            await _context.SaveChangesAsync();

            nguoiThucHien ??= "Unknown";
            var log = new AuditLog
            {
                TenBang = nameof(NhanVien),
                IdBanGhi = nv.Id,
                HanhDong = "Tao",
                GiaTriCu = null,
                GiaTriMoi = JsonSerializer.Serialize(ToViewDto(nv)),
                NguoiThucHien = nguoiThucHien,
                ThoiGian = DateTime.Now
            };

            _context.AuditLogs.Add(log);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = nv.Id }, ToViewDto(nv));
        }

        [HttpPut("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Update(
            int id,
            NhanVienCreateUpdateDto dto,
            [FromHeader(Name = "X-NguoiThucHien")] string? nguoiThucHien)
        {
            var nv = await _context.NhanViens.FindAsync(id);
            if (nv == null) return NotFound();

            var giaTriCu = JsonSerializer.Serialize(ToViewDto(nv));

            if (!string.IsNullOrWhiteSpace(dto.MaNhanVien))
            {
                var ma = dto.MaNhanVien.Trim();

                if (!string.Equals(nv.MaNhanVien, ma, StringComparison.OrdinalIgnoreCase))
                {
                    var existed = await _context.NhanViens.AnyAsync(x => x.MaNhanVien == ma && x.Id != id);
                    if (existed)
                        return BadRequest("Mã nhân viên đã tồn tại.");

                    nv.MaNhanVien = ma;
                    nv.TenDangNhap = ma; // 👈 đồng bộ username
                }
            }

            nv.HoTen = dto.HoTen;
            nv.VaiTro = string.IsNullOrWhiteSpace(dto.VaiTro) ? nv.VaiTro : dto.VaiTro;

            await _context.SaveChangesAsync();

            nguoiThucHien ??= "Unknown";
            var giaTriMoi = JsonSerializer.Serialize(ToViewDto(nv));

            var log = new AuditLog
            {
                TenBang = nameof(NhanVien),
                IdBanGhi = id,
                HanhDong = "Sua",
                GiaTriCu = giaTriCu,
                GiaTriMoi = giaTriMoi,
                NguoiThucHien = nguoiThucHien,
                ThoiGian = DateTime.Now
            };

            _context.AuditLogs.Add(log);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPut("{id:int}/set-password")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> SetPassword(
            int id,
            SetPasswordDto dto,
            [FromHeader(Name = "X-NguoiThucHien")] string? nguoiThucHien)
        {
            if (string.IsNullOrWhiteSpace(dto.MatKhauMoi))
                return BadRequest("Mật khẩu mới là bắt buộc.");

            var nv = await _context.NhanViens.FindAsync(id);
            if (nv == null) return NotFound();

            var giaTriCu = JsonSerializer.Serialize(ToViewDto(nv));

            nv.MatKhauHash = PasswordHasher.CreatePasswordHash(dto.MatKhauMoi);
            await _context.SaveChangesAsync();

            // 🔔 Audit log
            nguoiThucHien ??= "Unknown";
            var log = new AuditLog
            {
                TenBang = nameof(NhanVien),
                IdBanGhi = id,
                HanhDong = "DoiMatKhau",
                GiaTriCu = giaTriCu,
                GiaTriMoi = null,
                NguoiThucHien = nguoiThucHien,
                ThoiGian = DateTime.Now
            };

            _context.AuditLogs.Add(log);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Đặt lại mật khẩu thành công." });
        }

        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(
            int id,
            [FromHeader(Name = "X-NguoiThucHien")] string? nguoiThucHien)
        {
            var nv = await _context.NhanViens.FindAsync(id);
            if (nv == null) return NotFound();

            var giaTriCu = JsonSerializer.Serialize(ToViewDto(nv));

            _context.NhanViens.Remove(nv);
            await _context.SaveChangesAsync();

            // 🔔 Audit log
            nguoiThucHien ??= "Unknown";
            var log = new AuditLog
            {
                TenBang = nameof(NhanVien),
                IdBanGhi = id,
                HanhDong = "Xoa",
                GiaTriCu = giaTriCu,
                GiaTriMoi = null,
                NguoiThucHien = nguoiThucHien,
                ThoiGian = DateTime.Now
            };

            _context.AuditLogs.Add(log);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
