﻿namespace API.DTOs
{
    public class SetPasswordDto
    {
        public string MatKhauMoi { get; set; } = null!;
    }
}
