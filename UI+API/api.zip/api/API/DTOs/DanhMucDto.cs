﻿namespace API.DTOs
{
    public class DanhMucCreateUpdateDto
    {
        public string Ten { get; set; } = null!;
        public bool DangHoatDong { get; set; }
    }
}
