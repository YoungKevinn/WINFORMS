﻿namespace API.DTOs
{
    public class NhanVienViewDto
    {
        public int Id { get; set; }
        public string? MaNhanVien { get; set; }
        public string HoTen { get; set; } = null!;
        public string VaiTro { get; set; } = null!;
        public string? TenDangNhap { get; set; }
    }

    public class NhanVienCreateUpdateDto
    {
        public string? MaNhanVien { get; set; }
        public string HoTen { get; set; } = null!;
        public string VaiTro { get; set; } = null!;
    }
}
