﻿namespace API.DTOs
{
    public class ChangePasswordDto
    {
        public string MatKhauCu { get; set; } = null!;
        public string MatKhauMoi { get; set; } = null!;

    }
}
