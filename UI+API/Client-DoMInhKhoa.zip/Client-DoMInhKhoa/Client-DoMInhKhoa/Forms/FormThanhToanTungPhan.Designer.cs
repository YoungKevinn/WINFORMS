﻿namespace Client_DoMInhKhoa.Forms
{
    partial class FormThanhToanQR
    {
        
    }
}
